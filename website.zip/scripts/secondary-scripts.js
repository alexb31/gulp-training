var max = 10;

for (i = 0; i < max; i++) {
    console.log(i);
}